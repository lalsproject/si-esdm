var json_NONLOGAMBATUAN_5 = {
"type": "FeatureCollection",
"name": "NONLOGAMBATUAN_5",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": 
}
